$(function(){
    //Slick slider part start 
      $('.slider_ban').slick({
          autoplay: true,
          arrows: false,
          dots: false,
      });
    // Slick slider part end
});